#!/bin/bash
mkdir -p /opt/challenge
echo "Find the flag in a running process." > /opt/challenge/START_HERE
(exec -a "secret-agent-flag{process_secret_id}" sleep 99999) &
(exec -a "watcher-flag{pid_hunter}" sleep 99999) &
chmod -R 755 /opt/challenge
