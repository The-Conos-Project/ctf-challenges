#!/bin/bash
mkdir -p /opt/challenge
echo "Find the flag in the command execution history." > /opt/challenge/START_HERE
echo 'echo "flag{history_repeats_itself}"' >> /etc/skel/.bash_history
echo 'echo "flag{history_tells_no_lies}"' >> /etc/skel/.bash_history
chmod -R 755 /opt/challenge
