# Linux Training Trail

This package contains ten introductory Linux CTF exercises in one SSH lab.
Start the container from CTFploy, connect with the credentials shown in the
platform, and read each directory's `START_HERE` file before investigating.

The exercises cover Bash history, file reading, environment variables, hidden
files, `find`, `grep`, local services, permissions, processes, and archives.
Each solved flag uses the `CN{...}` format.
