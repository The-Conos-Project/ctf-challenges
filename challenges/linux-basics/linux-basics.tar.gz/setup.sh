SSH_PASSWORD="${SSH_PASSWORD:-}"

if [[ -n "$SSH_USER" ]]; then
    id "$SSH_USER" >/dev/null 2>&1 || useradd -m -s /bin/bash "$SSH_USER"
    printf '%s:%s\n' "$SSH_USER" "$SSH_PASSWORD" | chpasswd
fi

if [[ -n "$CHALLENGE_NAME" ]]; then
    case "$CHALLENGE_NAME" in
