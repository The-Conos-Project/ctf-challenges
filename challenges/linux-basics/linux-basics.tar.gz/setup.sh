#!/bin/bash
set -e

CHALLENGE_NAME="${CHALLENGE_NAME:-}"
SSH_USER="${SSH_USER:-ctfuser}"
SSH_PASSWORD="${SSH_PASSWORD:-cinema}"

if [[ -n "$SSH_USER" ]]; then
    id "$SSH_USER" >/dev/null 2>&1 || useradd -m -s /bin/bash "$SSH_USER"
    printf '%s:%s\n' "$SSH_USER" "$SSH_PASSWORD" | chpasswd
fi

if [[ -n "$CHALLENGE_NAME" ]]; then
    case "$CHALLENGE_NAME" in
        challenge-01-path_to_current_directory) setup_challenge_01_path_to_current_directory ;;
        challenge-02-navigate_to_home_directory) setup_challenge_02_navigate_to_home_directory ;;
        challenge-03-list_all_files_including_hidden) setup_challenge_03_list_all_files_including_hidden ;;
        challenge-04-file_type_identified) setup_challenge_04_file_type_identified ;;
        challenge-05-find_manual_page) setup_challenge_05_find_manual_page ;;
        challenge-06-filesystem_hierarchy_explorer) setup_challenge_06_filesystem_hierarchy_explorer ;;
        challenge-07-environment_variable_spotted) setup_challenge_07_environment_variable_spotted ;;
        challenge-08-path_variable_inspected) setup_challenge_08_path_variable_inspected ;;
        challenge-09-copied_file_verified) setup_challenge_09_copied_file_verified ;;
        challenge-10-symlink_created_successfully) setup_challenge_10_symlink_created_successfully ;;
        challenge-11-hard_link_created) setup_challenge_11_hard_link_created ;;
        challenge-12-find_nested_flag_file) setup_challenge_12_find_nested_flag_file ;;
        challenge-13-locate_database_search) setup_challenge_13_locate_database_search ;;
        challenge-14-redirect_output_to_file) setup_challenge_14_redirect_output_to_file ;;
        challenge-15-pipe_and_filter_logs) setup_challenge_15_pipe_and_filter_logs ;;
        challenge-16-extract_fields_with_cut) setup_challenge_16_extract_fields_with_cut ;;
        challenge-17-user_account_discovered) setup_challenge_17_user_account_discovered ;;
        challenge-18-sudo_command_executed) setup_challenge_18_sudo_command_executed ;;
        challenge-19-permissions_changed_successfully) setup_challenge_19_permissions_changed_successfully ;;
        challenge-20-special_permission_set) setup_challenge_20_special_permission_set ;;
        challenge-21-process_found_by_name) setup_challenge_21_process_found_by_name ;;
        challenge-22-background_job_controlled) setup_challenge_22_background_job_controlled ;;
        challenge-23-cron_job_listed) setup_challenge_23_cron_job_listed ;;
        challenge-24-log_file_analyzed) setup_challenge_24_log_file_analyzed ;;
        challenge-25-disk_usage_checked) setup_challenge_25_disk_usage_checked ;;
        *) echo "Unknown challenge: $CHALLENGE_NAME" ;;
    esac
    exit 0
fi
setup_challenge_01_path_to_current_directory() {
    mkdir -p /home/ctfuser/challenges/flag1
    cat > /home/ctfuser/challenges/flag1/README.md <<'EOF'
Challenge 1: Print the absolute path of your current working directory.

Hints:
- The terminal can tell you where you are.
- A common builtin prints the working directory.
EOF
    cat > /home/ctfuser/challenges/flag1/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{path_to_current_directory}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag1/checker
    chmod 700 /home/ctfuser/challenges/flag1/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag1/README.md
    chmod 644 /home/ctfuser/challenges/flag1/README.md
}

setup_challenge_02_navigate_to_home_directory() {
    mkdir -p /home/ctfuser/challenges/flag2
    cat > /home/ctfuser/challenges/flag2/README.md <<'EOF'
Challenge 2: Change to your home directory and confirm your location.

Hints:
- There is a shortcut to return to your home directory.
- Verify your location after moving.
EOF
    cat > /home/ctfuser/challenges/flag2/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{navigate_to_home_directory}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag2/checker
    chmod 700 /home/ctfuser/challenges/flag2/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag2/README.md
    chmod 644 /home/ctfuser/challenges/flag2/README.md
}

setup_challenge_03_list_all_files_including_hidden() {
    mkdir -p /home/ctfuser/challenges/flag3
    cat > /home/ctfuser/challenges/flag3/README.md <<'EOF'
Challenge 3: List all files in the current directory, including hidden ones.

Hints:
- Not everything is shown by default.
- Some entries begin with a dot.
EOF
    cat > /home/ctfuser/challenges/flag3/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{list_all_files_including_hidden}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag3/checker
    chmod 700 /home/ctfuser/challenges/flag3/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag3/README.md
    chmod 644 /home/ctfuser/challenges/flag3/README.md
}

setup_challenge_04_file_type_identified() {
    mkdir -p /home/ctfuser/challenges/flag4
    cat > /home/ctfuser/challenges/flag4/README.md <<'EOF'
Challenge 4: Identify the type of a mystery file without reading its contents.

Hints:
- Magic bytes reveal file types.
- A common utility can inspect file headers.
EOF
    cat > /home/ctfuser/challenges/flag4/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{file_type_identified}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag4/checker
    chmod 700 /home/ctfuser/challenges/flag4/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag4/README.md
    chmod 644 /home/ctfuser/challenges/flag4/README.md
}

setup_challenge_05_find_manual_page() {
    mkdir -p /home/ctfuser/challenges/flag5
    cat > /home/ctfuser/challenges/flag5/README.md <<'EOF'
Challenge 5: Discover which manual section contains the passwd command reference.

Hints:
- Built-in documentation is organized into sections.
- System file formats often live in section 5.
EOF
    cat > /home/ctfuser/challenges/flag5/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{find_manual_page}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag5/checker
    chmod 700 /home/ctfuser/challenges/flag5/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag5/README.md
    chmod 644 /home/ctfuser/challenges/flag5/README.md
}

setup_challenge_06_filesystem_hierarchy_explorer() {
    mkdir -p /home/ctfuser/challenges/flag6
    cat > /home/ctfuser/challenges/flag6/README.md <<'EOF'
Challenge 6: Locate the directory that contains system configuration files.

Hints:
- The standard hierarchy groups configuration under one top-level directory.
- Look for files like hosts, resolv.conf, or similar system files.
EOF
    cat > /home/ctfuser/challenges/flag6/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{filesystem_hierarchy_explorer}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag6/checker
    chmod 700 /home/ctfuser/challenges/flag6/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag6/README.md
    chmod 644 /home/ctfuser/challenges/flag6/README.md
}

setup_challenge_07_environment_variable_spotted() {
    mkdir -p /home/ctfuser/challenges/flag7
    cat > /home/ctfuser/challenges/flag7/README.md <<'EOF'
Challenge 7: Read the value of a hidden environment variable named SECRET_KEY.

Hints:
- Processes inherit settings from their environment.
- List environment variables and search for SECRET_KEY.
EOF
    cat > /home/ctfuser/challenges/flag7/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{environment_variable_spotted}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag7/checker
    chmod 700 /home/ctfuser/challenges/flag7/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag7/README.md
    chmod 644 /home/ctfuser/challenges/flag7/README.md
}

setup_challenge_08_path_variable_inspected() {
    mkdir -p /home/ctfuser/challenges/flag8
    cat > /home/ctfuser/challenges/flag8/README.md <<'EOF'
Challenge 8: Inspect your PATH variable and identify all directories searched for executables.

Hints:
- The shell searches a list of directories when you run a command.
- This list is stored in a variable and separated by colons.
EOF
    cat > /home/ctfuser/challenges/flag8/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{path_variable_inspected}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag8/checker
    chmod 700 /home/ctfuser/challenges/flag8/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag8/README.md
    chmod 644 /home/ctfuser/challenges/flag8/README.md
}

setup_challenge_09_copied_file_verified() {
    mkdir -p /home/ctfuser/challenges/flag9
    cat > /home/ctfuser/challenges/flag9/README.md <<'EOF'
Challenge 9: Copy a template file and verify it exists in the destination.

Hints:
- Standard file duplication command.
- Confirm the new file exists.
EOF
    cat > /home/ctfuser/challenges/flag9/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{copied_file_verified}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag9/checker
    chmod 700 /home/ctfuser/challenges/flag9/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag9/README.md
    chmod 644 /home/ctfuser/challenges/flag9/README.md
}

setup_challenge_10_symlink_created_successfully() {
    mkdir -p /home/ctfuser/challenges/flag10
    cat > /home/ctfuser/challenges/flag10/README.md <<'EOF'
Challenge 10: Create a symbolic link and confirm it points to the correct target.

Hints:
- A pointer file can reference another path.
- List the link to see its target.
EOF
    cat > /home/ctfuser/challenges/flag10/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{symlink_created_successfully}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag10/checker
    chmod 700 /home/ctfuser/challenges/flag10/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag10/README.md
    chmod 644 /home/ctfuser/challenges/flag10/README.md
}

setup_challenge_11_hard_link_created() {
    mkdir -p /home/ctfuser/challenges/flag11
    cat > /home/ctfuser/challenges/flag11/README.md <<'EOF'
Challenge 11: Create a hard link and verify both files share the same inode.

Hints:
- Two names can reference the same underlying data.
- Inode numbers remain identical.
EOF
    cat > /home/ctfuser/challenges/flag11/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{hard_link_created}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag11/checker
    chmod 700 /home/ctfuser/challenges/flag11/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag11/README.md
    chmod 644 /home/ctfuser/challenges/flag11/README.md
}

setup_challenge_12_find_nested_flag_file() {
    mkdir -p /home/ctfuser/challenges/flag12
    cat > /home/ctfuser/challenges/flag12/README.md <<'EOF'
Challenge 12: Search recursively for a file named hidden_flag.txt.

Hints:
- Recursive search is faster than manual exploration.
- Filter by filename pattern.
EOF
    cat > /home/ctfuser/challenges/flag12/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{find_nested_flag_file}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag12/checker
    chmod 700 /home/ctfuser/challenges/flag12/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag12/README.md
    chmod 644 /home/ctfuser/challenges/flag12/README.md
}

setup_challenge_13_locate_database_search() {
    mkdir -p /home/ctfuser/challenges/flag13
    cat > /home/ctfuser/challenges/flag13/README.md <<'EOF'
Challenge 13: Use locate to find a file named old_config.yaml.

Hints:
- An indexed database can speed up searches.
- The database may need updating first.
EOF
    cat > /home/ctfuser/challenges/flag13/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{locate_database_search}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag13/checker
    chmod 700 /home/ctfuser/challenges/flag13/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag13/README.md
    chmod 644 /home/ctfuser/challenges/flag13/README.md
}

setup_challenge_14_redirect_output_to_file() {
    mkdir -p /home/ctfuser/challenges/flag14
    cat > /home/ctfuser/challenges/flag14/README.md <<'EOF'
Challenge 14: Redirect the output of a command into a file named result.txt.

Hints:
- Send command output to a file.
- Overwrite or append as needed.
EOF
    cat > /home/ctfuser/challenges/flag14/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{redirect_output_to_file}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag14/checker
    chmod 700 /home/ctfuser/challenges/flag14/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag14/README.md
    chmod 644 /home/ctfuser/challenges/flag14/README.md
}

setup_challenge_15_pipe_and_filter_logs() {
    mkdir -p /home/ctfuser/challenges/flag15
    cat > /home/ctfuser/challenges/flag15/README.md <<'EOF'
Challenge 15: Use a pipe to count how many lines contain the word ERROR in a log file.

Hints:
- Connect commands together.
- Count matching lines without opening the file.
EOF
    cat > /home/ctfuser/challenges/flag15/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{pipe_and_filter_logs}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag15/checker
    chmod 700 /home/ctfuser/challenges/flag15/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag15/README.md
    chmod 644 /home/ctfuser/challenges/flag15/README.md
}

setup_challenge_16_extract_fields_with_cut() {
    mkdir -p /home/ctfuser/challenges/flag16
    cat > /home/ctfuser/challenges/flag16/README.md <<'EOF'
Challenge 16: Extract the third field from a colon-separated passwd-style file.

Hints:
- Delimited text can be split by column.
- The third field often stores a numeric ID.
EOF
    cat > /home/ctfuser/challenges/flag16/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{extract_fields_with_cut}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag16/checker
    chmod 700 /home/ctfuser/challenges/flag16/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag16/README.md
    chmod 644 /home/ctfuser/challenges/flag16/README.md
}

setup_challenge_17_user_account_discovered() {
    mkdir -p /home/ctfuser/challenges/flag17
    cat > /home/ctfuser/challenges/flag17/README.md <<'EOF'
Challenge 17: Find the home directory of the service account named sshd.

Hints:
- System accounts are listed in a central database.
- The 6th field usually holds the home directory.
EOF
    cat > /home/ctfuser/challenges/flag17/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{user_account_discovered}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag17/checker
    chmod 700 /home/ctfuser/challenges/flag17/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag17/README.md
    chmod 644 /home/ctfuser/challenges/flag17/README.md
}

setup_challenge_18_sudo_command_executed() {
    mkdir -p /home/ctfuser/challenges/flag18
    cat > /home/ctfuser/challenges/flag18/README.md <<'EOF'
Challenge 18: Execute a command with elevated privileges using sudo.

Hints:
- Run commands as another user, typically root.
- You may need to know the password.
EOF
    cat > /home/ctfuser/challenges/flag18/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{sudo_command_executed}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag18/checker
    chmod 700 /home/ctfuser/challenges/flag18/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag18/README.md
    chmod 644 /home/ctfuser/challenges/flag18/README.md
}

setup_challenge_19_permissions_changed_successfully() {
    mkdir -p /home/ctfuser/challenges/flag19
    cat > /home/ctfuser/challenges/flag19/README.md <<'EOF'
Challenge 19: Make a file readable only by its owner using chmod.

Hints:
- Numeric or symbolic modes can restrict access.
- Owner gets read+write; others get nothing.
EOF
    cat > /home/ctfuser/challenges/flag19/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{permissions_changed_successfully}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag19/checker
    chmod 700 /home/ctfuser/challenges/flag19/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag19/README.md
    chmod 644 /home/ctfuser/challenges/flag19/README.md
}

setup_challenge_20_special_permission_set() {
    mkdir -p /home/ctfuser/challenges/flag20
    cat > /home/ctfuser/challenges/flag20/README.md <<'EOF'
Challenge 20: Set the SUID bit on a binary and verify it with ls -l.

Hints:
- A special bit can make a binary run as its owner.
- In long listings, the owner execute bit may show as s.
EOF
    cat > /home/ctfuser/challenges/flag20/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{special_permission_set}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag20/checker
    chmod 700 /home/ctfuser/challenges/flag20/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag20/README.md
    chmod 644 /home/ctfuser/challenges/flag20/README.md
}

setup_challenge_21_process_found_by_name() {
    mkdir -p /home/ctfuser/challenges/flag21
    cat > /home/ctfuser/challenges/flag21/README.md <<'EOF'
Challenge 21: Find the PID of a running process named secret-daemon.

Hints:
- Process IDs can be queried directly by name.
- The process table also reveals command lines.
EOF
    cat > /home/ctfuser/challenges/flag21/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{process_found_by_name}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag21/checker
    chmod 700 /home/ctfuser/challenges/flag21/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag21/README.md
    chmod 644 /home/ctfuser/challenges/flag21/README.md
}

setup_challenge_22_background_job_controlled() {
    mkdir -p /home/ctfuser/challenges/flag22
    cat > /home/ctfuser/challenges/flag22/README.md <<'EOF'
Challenge 22: Start a sleep process in the background and bring it back to foreground.

Hints:
- Run a long process without blocking the terminal.
- Return it to the foreground when needed.
EOF
    cat > /home/ctfuser/challenges/flag22/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{background_job_controlled}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag22/checker
    chmod 700 /home/ctfuser/challenges/flag22/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag22/README.md
    chmod 644 /home/ctfuser/challenges/flag22/README.md
}

setup_challenge_23_cron_job_listed() {
    mkdir -p /home/ctfuser/challenges/flag23
    cat > /home/ctfuser/challenges/flag23/README.md <<'EOF'
Challenge 23: List all cron jobs for the current user.

Hints:
- Scheduled tasks can be queried per user.
- Look in spool directories too.
EOF
    cat > /home/ctfuser/challenges/flag23/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{cron_job_listed}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag23/checker
    chmod 700 /home/ctfuser/challenges/flag23/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag23/README.md
    chmod 644 /home/ctfuser/challenges/flag23/README.md
}

setup_challenge_24_log_file_analyzed() {
    mkdir -p /home/ctfuser/challenges/flag24
    cat > /home/ctfuser/challenges/flag24/README.md <<'EOF'
Challenge 24: Find the most recent failed SSH login attempt in auth.log.

Hints:
- Authentication logs record failed attempts.
- Filter and view the tail of the log.
EOF
    cat > /home/ctfuser/challenges/flag24/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{log_file_analyzed}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag24/checker
    chmod 700 /home/ctfuser/challenges/flag24/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag24/README.md
    chmod 644 /home/ctfuser/challenges/flag24/README.md
}

setup_challenge_25_disk_usage_checked() {
    mkdir -p /home/ctfuser/challenges/flag25
    cat > /home/ctfuser/challenges/flag25/README.md <<'EOF'
Challenge 25: Check the disk usage of the /home directory in human-readable format.

Hints:
- Summarize directory sizes or filesystem usage.
- Human-readable output helps interpretation.
EOF
    cat > /home/ctfuser/challenges/flag25/checker <<'EOF'
#!/bin/bash
REAL_FLAG="CN{disk_usage_checked}"
if [ "$1" = "$REAL_FLAG" ]; then
    echo "Correct!"
    exit 0
else
    echo "Wrong!"
    exit 1
fi
EOF
    chown root:root /home/ctfuser/challenges/flag25/checker
    chmod 700 /home/ctfuser/challenges/flag25/checker
    chown -R ctfuser:ctfuser /home/ctfuser/challenges/flag25/README.md
    chmod 644 /home/ctfuser/challenges/flag25/README.md
}

chmod -R a=rX /home/ctfuser/challenges
find /home/ctfuser/challenges -type d -exec chmod 755 {} \;
