#!/bin/bash
set -e

SSH_USER="${SSH_USER:-ctfuser}"
SSH_PASSWORD="${SSH_PASSWORD:-cinema}"

if [[ -n "$SSH_USER" ]]; then
    id "$SSH_USER" >/dev/null 2>&1 || useradd -m -s /bin/bash "$SSH_USER"
    printf '%s:%s\n' "$SSH_USER" "$SSH_PASSWORD" | chpasswd
fi
