#!/bin/bash
set -e

CHALLENGE_NAME="${CHALLENGE_NAME:-}"

if [[ -n "$CHALLENGE_NAME" ]]; then
    case "$CHALLENGE_NAME" in
        challenge-01-path_to_current_directory) setup_challenge_01_path_to_current_directory ;;
        challenge-02-navigate_to_home_directory) setup_challenge_02_navigate_to_home_directory ;;
        challenge-03-list_all_files_including_hidden) setup_challenge_03_list_all_files_including_hidden ;;
        challenge-04-file_type_identified) setup_challenge_04_file_type_identified ;;
        challenge-05-find_manual_page) setup_challenge_05_find_manual_page ;;
        challenge-06-filesystem_hierarchy_explorer) setup_challenge_06_filesystem_hierarchy_explorer ;;
        challenge-07-environment_variable_spotted) setup_challenge_07_environment_variable_spotted ;;
        challenge-08-path_variable_inspected) setup_challenge_08_path_variable_inspected ;;
        challenge-09-copied_file_verified) setup_challenge_09_copied_file_verified ;;
        challenge-10-symlink_created_successfully) setup_challenge_10_symlink_created_successfully ;;
        challenge-11-hard_link_created) setup_challenge_11_hard_link_created ;;
        challenge-12-find_nested_flag_file) setup_challenge_12_find_nested_flag_file ;;
        challenge-13-locate_database_search) setup_challenge_13_locate_database_search ;;
        challenge-14-redirect_output_to_file) setup_challenge_14_redirect_output_to_file ;;
        challenge-15-pipe_and_filter_logs) setup_challenge_15_pipe_and_filter_logs ;;
        challenge-16-extract_fields_with_cut) setup_challenge_16_extract_fields_with_cut ;;
        challenge-17-user_account_discovered) setup_challenge_17_user_account_discovered ;;
        challenge-18-sudo_command_executed) setup_challenge_18_sudo_command_executed ;;
        challenge-19-permissions_changed_successfully) setup_challenge_19_permissions_changed_successfully ;;
        challenge-20-special_permission_set) setup_challenge_20_special_permission_set ;;
        challenge-21-process_found_by_name) setup_challenge_21_process_found_by_name ;;
        challenge-22-background_job_controlled) setup_challenge_22_background_job_controlled ;;
        challenge-23-cron_job_listed) setup_challenge_23_cron_job_listed ;;
        challenge-24-log_file_analyzed) setup_challenge_24_log_file_analyzed ;;
        challenge-25-disk_usage_checked) setup_challenge_25_disk_usage_checked ;;
        *) echo "Unknown challenge: $CHALLENGE_NAME" ;;
    esac
    exit 0
fi
setup_challenge_01_path_to_current_directory() {
    mkdir -p /opt/challenges/challenge-01
    cat > /opt/challenges/challenge-01/START_HERE <<'EOF'
Challenge 1: Print the absolute path of your current working directory.
EOF
    echo "flag{path_to_current_directory}" > /opt/challenges/challenge-01/flag.txt
}

setup_challenge_02_navigate_to_home_directory() {
    mkdir -p /opt/challenges/challenge-02
    cat > /opt/challenges/challenge-02/START_HERE <<'EOF'
Challenge 2: Change to your home directory and confirm with pwd.
EOF
    echo "flag{navigate_to_home_directory}" > /opt/challenges/challenge-02/flag.txt
}

setup_challenge_03_list_all_files_including_hidden() {
    mkdir -p /opt/challenges/challenge-03
    cat > /opt/challenges/challenge-03/START_HERE <<'EOF'
Challenge 3: List all files in the current directory, including hidden ones.
EOF
    echo "flag{list_all_files_including_hidden}" > /opt/challenges/challenge-03/.hidden_flag
}

setup_challenge_04_file_type_identified() {
    mkdir -p /opt/challenges/challenge-04
    cat > /opt/challenges/challenge-04/START_HERE <<'EOF'
Challenge 4: Identify the type of a mystery file without reading its contents.
EOF
    echo "#!/bin/bash" > /opt/challenges/challenge-04/mystery_binary
    chmod +x /opt/challenges/challenge-04/mystery_binary
    echo "flag{file_type_identified}" > /opt/challenges/challenge-04/flag.txt
}

setup_challenge_05_find_manual_page() {
    mkdir -p /opt/challenges/challenge-05
    cat > /opt/challenges/challenge-05/START_HERE <<'EOF'
Challenge 5: Discover which manual section contains the passwd command reference.
EOF
    echo "flag{find_manual_page}" > /opt/challenges/challenge-05/flag.txt
}

setup_challenge_06_filesystem_hierarchy_explorer() {
    mkdir -p /opt/challenges/challenge-06
    cat > /opt/challenges/challenge-06/START_HERE <<'EOF'
Challenge 6: Locate the directory that contains system configuration files.
EOF
    mkdir -p /opt/challenges/challenge-06/etc
    echo "flag{filesystem_hierarchy_explorer}" > /opt/challenges/challenge-06/etc/system_config
}

setup_challenge_07_environment_variable_spotted() {
    mkdir -p /opt/challenges/challenge-07
    cat > /opt/challenges/challenge-07/START_HERE <<'EOF'
Challenge 7: Read the value of a hidden environment variable named SECRET_KEY.
EOF
    echo "export SECRET_KEY=flag{environment_variable_spotted}" > /etc/profile.d/challenge-07.sh
}

setup_challenge_08_path_variable_inspected() {
    mkdir -p /opt/challenges/challenge-08
    cat > /opt/challenges/challenge-08/START_HERE <<'EOF'
Challenge 8: Inspect your PATH variable and identify all directories searched for executables.
EOF
    echo "flag{path_variable_inspected}" > /opt/challenges/challenge-08/flag.txt
}

setup_challenge_09_copied_file_verified() {
    mkdir -p /opt/challenges/challenge-09
    cat > /opt/challenges/challenge-09/START_HERE <<'EOF'
Challenge 9: Copy a template file and verify it exists in the destination.
EOF
    echo "original content" > /opt/challenges/challenge-09/source.txt
    cp /opt/challenges/challenge-09/source.txt /opt/challenges/challenge-09/destination.txt
    echo "flag{copied_file_verified}" > /opt/challenges/challenge-09/flag.txt
}

setup_challenge_10_symlink_created_successfully() {
    mkdir -p /opt/challenges/challenge-10
    cat > /opt/challenges/challenge-10/START_HERE <<'EOF'
Challenge 10: Create a symbolic link and confirm it points to the correct target.
EOF
    echo "target content" > /opt/challenges/challenge-10/target.txt
    ln -s /opt/challenges/challenge-10/target.txt /opt/challenges/challenge-10/link.txt
    echo "flag{symlink_created_successfully}" > /opt/challenges/challenge-10/flag.txt
}

setup_challenge_11_hard_link_created() {
    mkdir -p /opt/challenges/challenge-11
    cat > /opt/challenges/challenge-11/START_HERE <<'EOF'
Challenge 11: Create a hard link and verify both files share the same inode.
EOF
    echo "shared content" > /opt/challenges/challenge-11/original.txt
    ln /opt/challenges/challenge-11/original.txt /opt/challenges/challenge-11/hardlink.txt
    echo "flag{hard_link_created}" > /opt/challenges/challenge-11/flag.txt
}

setup_challenge_12_find_nested_flag_file() {
    mkdir -p /opt/challenges/challenge-12
    cat > /opt/challenges/challenge-12/START_HERE <<'EOF'
Challenge 12: Search recursively for a file named hidden_flag.txt.
EOF
    mkdir -p /opt/challenges/challenge-12/a/b/c/d
    echo "flag{find_nested_flag_file}" > /opt/challenges/challenge-12/a/b/c/d/hidden_flag.txt
}

setup_challenge_13_locate_database_search() {
    mkdir -p /opt/challenges/challenge-13
    cat > /opt/challenges/challenge-13/START_HERE <<'EOF'
Challenge 13: Use locate to find a file named old_config.yaml.
EOF
    mkdir -p /opt/challenges/challenge-13/data
    echo "config file" > /opt/challenges/challenge-13/data/old_config.yaml
    updatedb
    echo "flag{locate_database_search}" > /opt/challenges/challenge-13/flag.txt
}

setup_challenge_14_redirect_output_to_file() {
    mkdir -p /opt/challenges/challenge-14
    cat > /opt/challenges/challenge-14/START_HERE <<'EOF'
Challenge 14: Redirect the output of a command into a file named result.txt.
EOF
    echo "flag{redirect_output_to_file}" > /opt/challenges/challenge-14/flag.txt
}

setup_challenge_15_pipe_and_filter_logs() {
    mkdir -p /opt/challenges/challenge-15
    cat > /opt/challenges/challenge-15/START_HERE <<'EOF'
Challenge 15: Use a pipe to count how many lines contain the word ERROR in a log file.
EOF
    for j in $(seq 1 100); do echo "[INFO] Normal operation"; done >> /opt/challenges/challenge-15/access.log
    echo "[ERROR] Connection timeout flag{pipe_and_filter_logs}" >> /opt/challenges/challenge-15/access.log
    for j in $(seq 1 100); do echo "[INFO] Normal operation"; done >> /opt/challenges/challenge-15/access.log
}

setup_challenge_16_extract_fields_with_cut() {
    mkdir -p /opt/challenges/challenge-16
    cat > /opt/challenges/challenge-16/START_HERE <<'EOF'
Challenge 16: Extract the third field from a colon-separated passwd-style file.
EOF
    echo "root:x:0:0:root:/root:/bin/bash" > /opt/challenges/challenge-16/mini_passwd
    echo "daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin" >> /opt/challenges/challenge-16/mini_passwd
    echo "flag{extract_fields_with_cut}" > /opt/challenges/challenge-16/flag.txt
}

setup_challenge_17_user_account_discovered() {
    mkdir -p /opt/challenges/challenge-17
    cat > /opt/challenges/challenge-17/START_HERE <<'EOF'
Challenge 17: Find the home directory of the service account named sshd.
EOF
    echo "sshd:x:128:65534::/run/sshd:/usr/sbin/nologin" > /opt/challenges/challenge-17/users.txt
    echo "flag{user_account_discovered}" > /opt/challenges/challenge-17/flag.txt
}

setup_challenge_18_sudo_command_executed() {
    mkdir -p /opt/challenges/challenge-18
    cat > /opt/challenges/challenge-18/START_HERE <<'EOF'
Challenge 18: Execute a command with elevated privileges using sudo.
EOF
    echo "flag{sudo_command_executed}" > /opt/challenges/challenge-18/flag.txt
}

setup_challenge_19_permissions_changed_successfully() {
    mkdir -p /opt/challenges/challenge-19
    cat > /opt/challenges/challenge-19/START_HERE <<'EOF'
Challenge 19: Make a file readable only by its owner using chmod.
EOF
    echo "secret data" > /opt/challenges/challenge-19/private.txt
    chmod 600 /opt/challenges/challenge-19/private.txt
    echo "flag{permissions_changed_successfully}" > /opt/challenges/challenge-19/flag.txt
}

setup_challenge_20_special_permission_set() {
    mkdir -p /opt/challenges/challenge-20
    cat > /opt/challenges/challenge-20/START_HERE <<'EOF'
Challenge 20: Set the SUID bit on a binary and verify it with ls -l.
EOF
    cp /bin/sleep /opt/challenges/challenge-20/setuid-sleep
    chmod u+s /opt/challenges/challenge-20/setuid-sleep
    echo "flag{special_permission_set}" > /opt/challenges/challenge-20/flag.txt
}

setup_challenge_21_process_found_by_name() {
    mkdir -p /opt/challenges/challenge-21
    cat > /opt/challenges/challenge-21/START_HERE <<'EOF'
Challenge 21: Find the PID of a running process named secret-daemon.
EOF
    (exec -a "secret-daemon" sleep 99999 &>/dev/null &)
    echo "flag{process_found_by_name}" > /opt/challenges/challenge-21/flag.txt
}

setup_challenge_22_background_job_controlled() {
    mkdir -p /opt/challenges/challenge-22
    cat > /opt/challenges/challenge-22/START_HERE <<'EOF'
Challenge 22: Start a sleep process in the background and bring it back to foreground.
EOF
    echo "flag{background_job_controlled}" > /opt/challenges/challenge-22/flag.txt
}

setup_challenge_23_cron_job_listed() {
    mkdir -p /opt/challenges/challenge-23
    cat > /opt/challenges/challenge-23/START_HERE <<'EOF'
Challenge 23: List all cron jobs for the current user.
EOF
    echo "flag{cron_job_listed}" > /opt/challenges/challenge-23/flag.txt
}

setup_challenge_24_log_file_analyzed() {
    mkdir -p /opt/challenges/challenge-24
    cat > /opt/challenges/challenge-24/START_HERE <<'EOF'
Challenge 24: Find the most recent failed SSH login attempt in auth.log.
EOF
    mkdir -p /var/log/challenge-24
    echo "Aug 16 12:00:01 server sshd[1234]: Failed password for invalid user admin from 1.2.3.4 port 22 ssh2" > /var/log/challenge-24/auth.log
    echo "flag{log_file_analyzed}" > /opt/challenges/challenge-24/flag.txt
}

setup_challenge_25_disk_usage_checked() {
    mkdir -p /opt/challenges/challenge-25
    cat > /opt/challenges/challenge-25/START_HERE <<'EOF'
Challenge 25: Check the disk usage of the /home directory in human-readable format.
EOF
    echo "flag{disk_usage_checked}" > /opt/challenges/challenge-25/flag.txt
}

chmod -R a=rX /opt/challenges
find /opt/challenges -type d -exec chmod 755 {} \;
