Challenge 24: Find the most recent failed SSH login attempt in auth.log.

Hints:
- Authentication logs record failed attempts.
- Filter and view the tail of the log.
