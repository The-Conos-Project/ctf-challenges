Challenge 6: Locate the directory that contains system configuration files.

Hints:
- The standard hierarchy groups configuration under one top-level directory.
- Look for files like hosts, resolv.conf, or similar system files.
