Challenge 11: Create a hard link and verify both files share the same inode.

Hints:
- Two names can reference the same underlying data.
- Inode numbers remain identical.
