Challenge 22: Start a sleep process in the background and bring it back to foreground.

Hints:
- Run a long process without blocking the terminal.
- Return it to the foreground when needed.
