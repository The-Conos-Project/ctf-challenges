Challenge 8: Inspect your PATH variable and identify all directories searched for executables.

Hints:
- The shell searches a list of directories when you run a command.
- This list is stored in a variable and separated by colons.
