Challenge 21: Find the PID of a running process named secret-daemon.

Hints:
- Process IDs can be queried directly by name.
- The process table also reveals command lines.
