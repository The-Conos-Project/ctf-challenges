Challenge 16: Extract the third field from a colon-separated passwd-style file.

Hints:
- Delimited text can be split by column.
- The third field often stores a numeric ID.
