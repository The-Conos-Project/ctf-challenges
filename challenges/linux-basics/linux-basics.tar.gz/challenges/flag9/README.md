Challenge 9: Copy a template file and verify it exists in the destination.

Hints:
- Standard file duplication command.
- Confirm the new file exists.
