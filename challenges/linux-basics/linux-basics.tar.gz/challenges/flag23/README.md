Challenge 23: List all cron jobs for the current user.

Hints:
- Scheduled tasks can be queried per user.
- Look in spool directories too.
