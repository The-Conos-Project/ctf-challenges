Challenge 1: Print the absolute path of your current working directory.

Hints:
- The terminal can tell you where you are.
- A common builtin prints the working directory.
