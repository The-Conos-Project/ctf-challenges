Challenge 4: Identify the type of a mystery file without reading its contents.

Hints:
- Magic bytes reveal file types.
- A common utility can inspect file headers.
