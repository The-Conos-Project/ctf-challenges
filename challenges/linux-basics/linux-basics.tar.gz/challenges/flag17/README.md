Challenge 17: Find the home directory of the service account named sshd.

Hints:
- System accounts are listed in a central database.
- The 6th field usually holds the home directory.
