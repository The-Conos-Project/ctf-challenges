Challenge 5: Discover which manual section contains the passwd command reference.

Hints:
- Built-in documentation is organized into sections.
- System file formats often live in section 5.
