Challenge 7: Read the value of a hidden environment variable named SECRET_KEY.

Hints:
- Processes inherit settings from their environment.
- List environment variables and search for SECRET_KEY.
