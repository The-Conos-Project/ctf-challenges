Challenge 15: Use a pipe to count how many lines contain the word ERROR in a log file.

Hints:
- Connect commands together.
- Count matching lines without opening the file.
