Challenge 14: Redirect the output of a command into a file named result.txt.

Hints:
- Send command output to a file.
- Overwrite or append as needed.
