Challenge 10: Create a symbolic link and confirm it points to the correct target.

Hints:
- A pointer file can reference another path.
- List the link to see its target.
