Challenge 12: Search recursively for a file named hidden_flag.txt.

Hints:
- Recursive search is faster than manual exploration.
- Filter by filename pattern.
