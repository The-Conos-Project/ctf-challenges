Challenge 19: Make a file readable only by its owner using chmod.

Hints:
- Numeric or symbolic modes can restrict access.
- Owner gets read+write; others get nothing.
