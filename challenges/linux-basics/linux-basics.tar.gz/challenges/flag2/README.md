Challenge 2: Change to your home directory and confirm your location.

Hints:
- There is a shortcut to return to your home directory.
- Verify your location after moving.
