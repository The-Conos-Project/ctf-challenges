Challenge 20: Set the SUID bit on a binary and verify it with ls -l.

Hints:
- A special bit can make a binary run as its owner.
- In long listings, the owner execute bit may show as s.
