Challenge 18: Execute a command with elevated privileges using sudo.

Hints:
- Run commands as another user, typically root.
- You may need to know the password.
