Challenge 13: Use locate to find a file named old_config.yaml.

Hints:
- An indexed database can speed up searches.
- The database may need updating first.
