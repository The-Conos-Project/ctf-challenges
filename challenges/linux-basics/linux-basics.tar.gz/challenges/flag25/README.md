Challenge 25: Check the disk usage of the /home directory in human-readable format.

Hints:
- Summarize directory sizes or filesystem usage.
- Human-readable output helps interpretation.
