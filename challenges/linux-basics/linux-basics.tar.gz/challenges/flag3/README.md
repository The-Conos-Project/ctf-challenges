Challenge 3: List all files in the current directory, including hidden ones.

Hints:
- Not everything is shown by default.
- Some entries begin with a dot.
